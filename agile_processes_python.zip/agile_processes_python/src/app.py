def squares(x):
    # Perform calculus
    y = x ** 2
    return y

def cube(x):
    # Perform calculus
    y = x ** 3
    return y

if __name__ == "__main__":
    print(f"The square of 20 is: {squares(20)}")